/*
  This file implements the innards of the VM4V4 machine.  
  
  ***** Do not change this file at all!!!! *****
  
  This program code (rather than just the class file)
  is provided so that you may see what is going on 
  internally, in case it helps you with writing VMParse.java 
  
  (Remember that it's no use changing this file, as your
  work in VMParse.java will be marked with an original copy 
  of VM.java.  All of *your* code should be in VMParse.java only.)
                                                                   */
import java.io.*;  
import java.util.*;

public class VM {
  
  final int numMemoryCells = 256;

                                         // Usually the number of local
                                         // variables can vary, but for
                                         // simplicity, this is fixed, with
  final int numLocalVars = 4;            // 3 local variables starting at
  final int localVarsPointer = 0;        // memory location 0
  
  
  final int instructionLength = 2; 
  
  public Cell[] memory = new Cell[numMemoryCells];

  public int opStackPointer;             // The stack pointer. This can vary.
  
  public int programCounter;            // Points to which instruction is
                                        // currently being executed.
  


  public VM () {

    // initialises all memory cells with contents 0
    for (int i = 0; i < numMemoryCells; i++) 
      memory[i] = new Cell(0);


    // now to initialize the registers in the CPU...
    
    opStackPointer = 4;                  // It is not crucial to pick 5 as
                                         // a starting point for the stack pointer,
                                         // but I chose this because you can see it
                                         // easily on the screen for this value!

    programCounter = 64;                 // The program counter doesn't have to
                                         // start at 64 (hex value 0x40) either, but
                                         // this places it at the start of the
                                         // "method" area of the machine's memory
  }

	public void reset()
	{
		for (int c=0; c<numMemoryCells; c++)
			memory[c].setContents(0);
			
		programCounter = Integer.parseInt("40",16);
		opStackPointer = 5;
		
		
		
	}


 
/* Now assorted methods to implement the various instructions
   Should all be self-explanatory, given the descriptions of the
   individual opcodes in the assignment handout.                  */

  public void iadd() {
    // Performs a addition operation on the top two items on the stack.
    //
    // (Only works if stack has at least two values on it,
    // ie stack pointer is at least two greater than numLocalVars)
    incrementPC();
    if (opStackPointer >= numLocalVars+2) {
      int op2 = pop();
      int op1 = pop();
      push(op1+op2);
    }
  }

  public void isub() {
    // Performs a subtraction operation on the top two items on the stack.
    //
    // (Only works if stack has at least two values on it,
    // ie stack pointer is at least two greater than numLocalVars)
    incrementPC();
    if (opStackPointer >= numLocalVars+2) {
      int op2 = pop();
      int op1 = pop();
      push(op1-op2);
    }
  }

  public void imul() {
    // Performs a multiplication operation on the top two items on the stack.
    //
    // (Only works if stack has at least two values on it,
    // ie stack pointer is at least two greater than numLocalVars)
    incrementPC();
    if (opStackPointer >= numLocalVars+2) {
      int op2 = pop();
      int op1 = pop();
      push(op1*op2);
    }
  }

  public void idiv() {
    // Performs a division operation on the top two items on the stack.
    //
    // (Only works if stack has at least two values on it,
    // ie stack pointer is at least two greater than numLocalVars)
    incrementPC();
    if (opStackPointer >= numLocalVars+2) {
      int op2 = pop();
      int op1 = pop();
      push(op1/op2);
    }
  }

  public void irem() {
    // Performs an arithmetic "remainder" operation on the top two items on the stack.
    //
    // (Only works if stack has at least two values on it,
    // ie stack pointer is at least two greater than numLocalVars)
    incrementPC();
    if (opStackPointer >= numLocalVars+2) {
      int op2 = pop();
      int op1 = pop();
      push(op1%op2);
    }
  }

  public void iand() {
    // Performs an "AND" operation on the top two items on the stack.
    //
    // (Only works if stack has at least two values on it,
    // ie stack pointer is at least two greater than numLocalVars)
    incrementPC();
    if (opStackPointer >= numLocalVars+2) {
      int op2 = pop();
      int op1 = pop();
      push(op1 & op2);
    }
  
  }
  
  public void ior() {
    // Performs an "OR" operation on the top two items on the stack.
    //
    // (Only works if stack has at least two values on it,
    // ie stack pointer is at least two greater than numLocalVars)
    incrementPC();
    if (opStackPointer >= numLocalVars+2) {
      int op2 = pop();
      int op1 = pop();
      push(op1 | op2);
    }
  
  }

  public void ldc(int i) {
    incrementPC();
    push(i);    
  }

  public void iload(int i) {
    incrementPC();
    push(memory[localVarsPointer+i].getContents());    
  }

  public void istore(int i) {
    incrementPC();
    memory[localVarsPointer+i].setContents(pop());
  }

  public void goTo(int label) {
    programCounter = label;
  }
  
  public void ifeq(int label) {
    incrementPC();
    int i = pop();
    if (i == 0)
      goTo(label);
  }

  public int pop() {
    opStackPointer = opStackPointer - 1;
    return memory[opStackPointer].getContents();
  }
  
  public void push(int i) {
    memory[opStackPointer].setContents(i);
    opStackPointer = opStackPointer + 1;
  }
  
  public void incrementPC() {
    if ((programCounter + instructionLength) < numMemoryCells)
      programCounter = programCounter + instructionLength;
  }



class Cell {

  private int cellContents;  // The cell's contents are stored as an integer
                             // (If this was a real machine, it would contain
                             // 8 bits, but this is a simulation, and as we're
                             // using Java, it works out as a little easier in 
                             // practice to use an integer, which will work out 
                             // to be in the range -128 to +127 of course, as
                             // we're using twos complement 
    
  public Cell (int initial) {
    cellContents = initial;
  }
  
  public int getContents () {
    return cellContents;
  }
  
  public void setContents(int num) {
    cellContents = num;
  }
  
} // end of class Cell


} // end of class VM

