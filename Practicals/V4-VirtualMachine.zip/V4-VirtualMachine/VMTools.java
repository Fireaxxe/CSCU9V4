
/* The file VMTools will eventually contain all the code
   for string manipulation, and file input and output and is 
   the only file that will be marked for your assignment
   submission.
   
   All the method bodies that are required for your assignment 
   have already been defined. Your task is to put the relevant
   code into the methods to get them to do the task required of
   them. In some cases code snippets have been provided to give 
   you a clue.
*/

//You will need these packages
import java.io.*;                       
import java.util.*;                   
import java.awt.*;

public class VMTools {

  VM theMachine;              // This file needs to be able to reference
                              // the V4 virtual machine, as (for example) loading 
                              // a file, or executing an instruction may
                              // change the values stored in the machine's 
                              // memory and registers. You can access 
                              // machine memory by calling one of its operations
                              // as follows:
                              //
                              //     theMachine.memory[42].setContents(128);
                              //
                              // or 
                              //
                              //     int val = theMachine.memory[42].getContents();
                            
                              

  public VMTools (VM vm) {
    theMachine = vm;          // The reference to the machine is passed into
                              // this constructor from code in VMGui.java, which
                              // sets up the machine in the first place. You don't
                              // have to worry about how this is done... 
  }

// Start working on your code from here

// --- convertInteger2HexString ---
//
// This method should take the integer contained
// in 'value' and return an equivalent value in
// hexadecimal but represented as String.
public String convertInteger2HexString(int value)
{
	if (value < -128 || value > 255) return "NA";
	
	String big = Integer.toHexString(value);
	if (big.length() <= 2)
		return padOut(big,2,'0');
	else
		return padOut(big.substring(big.length()-2),2,'0');
		
}

public String unsignedToHexString(int value)
{
	if (value < 0 || value > 255) return "NA";
	
	String big = Integer.toHexString(value);
	if (big.length() <= 2)
		return padOut(big,2,'0');
	else
		return padOut(big.substring(big.length()-2),2,'0');
}

public int hexStringToInt(String mixhex)
{
	String hex = padOut(mixhex.toUpperCase(),2,'0');
	BitSet bits;
		
	if (hex.length() > 2) return 0;
	
	if (hex.length() == 1)
		bits = charToBitSet(hex.charAt(0),false);
	else
	{
		bits = charToBitSet(hex.charAt(0),true);
		bits.or(charToBitSet(hex.charAt(1),false));
	}

	// System.out.println("Hex:" + mixhex + " Bits:" + bitSetToString(bits) + " Val:" + bitSetToInt(bits));

	return bitSetToInt(bits);
}

public String intToByteString(int val)
{
	return bitSetToString(intToBitSet(val));
}


BitSet charToBitSet(char ch, boolean big)
{
	BitSet	binary = new BitSet(8);
	int		bit = 8;
	int		val = ch - '0';

	if (val > 9) val = 10 + ch - 'A'; 
	for (int p=0; p<4; p++)
	{
		if (val / bit > 0) 
		{
			if (big) binary.set(p); else binary.set(p+4);
			val = val - bit;
		}
		bit = bit / 2;
	}

	return binary;
}

BitSet intToBitSet(int v)
{
	BitSet	binary = new BitSet(8);
	int		bit = 64;
	int		val = v;
	boolean	negative = (val < 0);
	
	if (val < -128 || val > 127) return binary;
	
	if (negative) val = 128 + v;
	
	for (int p=1; p<8; p++)
	{
		if (val / bit > 0) 
		{
			binary.set(p);
			val = val - bit;
		}
		bit = bit / 2;
	}
	if (negative) binary.set(0);

	return binary;
}


int bitSetToInt(BitSet bits)
{
	int	bitval=1;
	int	val=0;
	
	for (int b=7; b>0; b--)
	{
		if (bits.get(b)) val = val + bitval;
		bitval *= 2;
	}
	// Check the sign bit
	if (bits.get(0)) return -128 + val; else return val;
}

String bitSetToString(BitSet bits)
{
	StringBuffer strbits = new StringBuffer("00000000");
	for (int b=0; b<8; b++)
		if (bits.get(b)) strbits.setCharAt(b,'1');
	return strbits.toString();
}

public String padOut(String txt, int pad, char ch)
{
	int	padding = pad - txt.length();

	if (padding <= 0) return txt;
	
	StringBuffer	padstr = new StringBuffer(padding);
	
	for (int c=0; c<padding; c++)	padstr.append(ch);
	return padstr.toString() + txt;
}

public String translate(String instruction)
{
	String	opcode = instruction.substring(0,2).toUpperCase();
	String	operand = new String("");
	String	mnm = new String("");
	
	// Check for addition etc.
	if (opcode.charAt(0) == '6')
	{
		if (opcode.charAt(1) == '0')      mnm = new String("iadd");
		else if (opcode.charAt(1) == '4') mnm = new String("isub");
		else if (opcode.charAt(1) == '8') mnm = new String("imul");
		else if (opcode.charAt(1) == 'C') mnm = new String("idiv");
	}
	
	if (mnm.length() == 0 && opcode.charAt(0) == '7')
	{
		if (opcode.charAt(1) == '0')      mnm = new String("irem");
		else if (opcode.charAt(1) == 'E') mnm = new String("iand");
	}

	if (mnm.length() == 0 && opcode.equals("80")) mnm = new String("ior");

	if (mnm.length() == 0)
	{
		if (opcode.equals("12")) mnm = new String("lcd  ");
		else if (opcode.equals("15")) mnm = new String("iload ");
		else if (opcode.equals("36")) mnm = new String("istore");
		else if (opcode.equals("A7")) mnm = new String("goto");
		else if (opcode.equals("99")) mnm = new String("ifeq");
		
		// If we have an instruction and therefore need an operand
		if (mnm.length() != 0) operand = instruction.substring(2).toUpperCase();
	}
	
	if (mnm.length() == 0) 
		return new String("NoOp");
	else
		return mnm + " " + operand;
}

public void executeInstruction(String instruction)
{
	// System.out.println("Executing: " + instruction);
	execute(instruction);
}

public boolean execute(String instruction)
{
	String	opcode = instruction.substring(0,2).toUpperCase();

	// System.out.println("opcode: '" + opcode + "'");
	
	// Check for addition etc.
	if (opcode.charAt(0) == '6')
	{
		if (opcode.charAt(1) == '0') { theMachine.iadd(); return true; }
		if (opcode.charAt(1) == '4') { theMachine.isub(); return true; }
		if (opcode.charAt(1) == '8') { theMachine.imul(); return true; }
		if (opcode.charAt(1) == 'C') { theMachine.idiv(); return true; }
	}
	
	if (opcode.charAt(0) == '7')
	{
		if (opcode.charAt(1) == '0') { theMachine.irem(); return true; }
		if (opcode.charAt(1) == 'E') { theMachine.iand(); return true; }
	}

	if (opcode.equals("80")) { theMachine.ior(); return true; }

	// The following ops may need an operand so grab it in case they do
	int operand = hexStringToInt(instruction.substring(2));
	if (opcode.equals("12")) { theMachine.ldc(operand); return true; }
	if (opcode.equals("15")) { theMachine.iload(operand); return true; }
	if (opcode.equals("36")) { theMachine.istore(operand); return true; }
	if (opcode.equals("A7")) { theMachine.goTo(operand); return true; }
	if (opcode.equals("99")) { theMachine.ifeq(operand); return true; }	

	return false;	
}
	
public void loadState(String filename)
{
	try 
	{
		BufferedReader 	in;
		String 				line;
		int					location;
		StringTokenizer	tokens;
		String				instruction;
	    
	   in = new BufferedReader(new FileReader(filename));
	   
	   // Read in the memory location
		line = in.readLine();
		tokens = new StringTokenizer(line," \t");
		location = hexStringToInt(tokens.nextToken());
		// System.out.println("Line: " + line + " Start:" + location );
		
		while ((line = in.readLine()) != null)
		{
			tokens = new StringTokenizer(line," \t");
			instruction = tokens.nextToken();
			theMachine.memory[location++].setContents(hexStringToInt(instruction.substring(0,2)));
			theMachine.memory[location++].setContents(hexStringToInt(instruction.substring(2,4)));
		}
		in.close();
   }
   catch (IOException e)
   {
   	System.out.println("Failed to open '" + filename + "': " + e.toString());
	}
	
}

public void saveState(String filename)
{
	try 
	{
	PrintWriter out = new PrintWriter(new FileWriter(filename));
	String		instruction;

   out.println("00"); 
   int l=0; 
   do 
   {
   	instruction = 	convertInteger2HexString(theMachine.memory[l++].getContents()) +
							convertInteger2HexString(theMachine.memory[l++].getContents());
   	out.println(instruction + "\t// " + translate(instruction));
	}
	while (l<theMachine.numMemoryCells); 
   out.close();
   }
   catch (IOException e)
   {
   	System.out.println("Failed to save '" + filename + "': " + e.toString());
	}
}

public String browseFile(Frame parent, boolean load) {
	
	FileDialog dlg;
	
	if (load)
		dlg = new FileDialog(parent,"Load Program",FileDialog.LOAD);
	else
		dlg = new FileDialog(parent,"Save Memory Dump",FileDialog.SAVE);
		
	dlg.setFile("*.txt");
	dlg.show();
	return dlg.getFile();

}


}