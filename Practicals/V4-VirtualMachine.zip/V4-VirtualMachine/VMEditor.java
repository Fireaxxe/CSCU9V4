import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.*;
import java.awt.*;
import java.util.StringTokenizer;

import java.io.*;

/**
 * 31V4 Assignment - Spring 2005
 * 
 * ID Number: XXXXXXXX - please put your ID number here.
 * 
 * Please put a cross against each method you have attempted:
 * 
 * 		browseFile	
 * 		saveFile		
 * 		loadFile		
 * 		padOut		
 * 		getHexInstruction	
 * 		getComment			
 * 		getBinaryForm
 *
 */

/**
 * The VMEditor class implements a stand alone editor which should help a
 * user to create assembly language programs for the V4 Virtual Machine.
 * All the code required to run this application is contained within this
 * file - there should be no need to create separate class files for your
 * solution.
 * 
 * The file is effectively split into two parts - the top half contains all
 * the initialisation and GUI creation code, the bottom half contains the method
 * definitions that you need to supply implementation code for. This division
 * is denoted by a commented line that states: "Assignment Code From Here Down"
 * If you wish to create your own new methods, please add them after this line
 * although you should find that all relevant method headers have been supplied
 * for you and that some even provide clues as to how to go about solving the problem.
 * 
 * Most of the methods that you are required to implement are called from the
 * 'actionPerformed' method which is situated close to the point where you
 * should add your code.
 *
 */
public class VMEditor extends JFrame implements ActionListener {

	// The interface is constructed from a small number of
	// JPanels and a List control, as follows:
	JPanel		codePane;	// A panel containg controls for selected instruction
	JPanel		btnPane;	// A panel for the 'Edit','Delete', 'Replace'... buttons
	List		codeList;	// A list control containing the lines of code
	JPanel		ioPane;		// A panel containing the IO text fields and buttons
	JPanel		gui;		// A panel containing the above panels
	
	GridBagLayout			gblGUI;	// These two controls are used to lay out the
	GridBagConstraints		conGUI;	// the above panels in a sensible way
	GridBagLayout			gblCode;	// These two controls are used to lay out the
	GridBagConstraints		conCode;	// the edit panel in a sensible way
	
	JTextField	inputFileNameTF;	// Text fields containing the input
	JTextField	outputFileNameTF;	// and output file names
	
	JTextField	instructionTF;		// Text fields containing the selected 
	JTextField	operandTF;			// instruction and operand
	
	JLabel		commentLbl;			// Labels to show a comment,
	JLabel		binaryInstruction;	// a binary version of an instruction and
	JLabel		binaryOperand;		// a binary version of an operand (parameter)
	
	JButton		loadFileBtn, saveFileBtn;		// Load and Save buttons
	JButton		loadBrowseBtn, saveBrowseBtn;	// Browse buttons for loading and saving
	JButton		editBtn, insertBtn;				// Edit and Insert buttons
	JButton		deleteBtn, replaceBtn;			// Delete and Replace buttons
	
	int			pad = 4;		// Pixel padding around buttons etc
	String 		sep = " ";		// The default delimiter to use, in this case a space character
	String		headerLine = "Hex  Instr   Comment";		// Header line for code listing
	
	/**
	 * The 'main' method is where our program starts running. It
	 * creates an instance of our VMEditor class, defines its
	 * size and title, then displays it to the user and waits for
	 * events to happen.
	 * 
	 * @param args	The command line arguments supplied to the program (ignored).
	 */
	public static void main(String args[])
	{
		VMEditor vme = new VMEditor();
		vme.setSize(640,480);
		vme.setTitle("VM Code Editor");
		vme.show();
	}
	
	/**
	 * The constructor for the VMEditor - this creates objects for all the
	 * object references defined above and puts together the GUI.
	 *
	 */
	public VMEditor()
	{	
		// Create the elements for the current instruction code pane
		instructionTF = new JTextField(6);
		operandTF = new JTextField(6);
		commentLbl = new JLabel(" ",SwingConstants.LEFT);
		
		binaryInstruction = new JLabel("00 [00000000]",SwingConstants.LEFT);
		binaryOperand = new JLabel("00 [00000000]",SwingConstants.LEFT);

		JLabel instrLBL = new JLabel("Instruction",SwingConstants.RIGHT);
		JLabel operandLBL = new JLabel("Operand",SwingConstants.RIGHT);
		JLabel commentHdr = new JLabel("Comment:",SwingConstants.RIGHT);
		JLabel blankLbl = new JLabel("",SwingConstants.LEFT);
		
		gblCode = new GridBagLayout();
		codePane = new JPanel(gblCode);
		
		conCode = new GridBagConstraints();
		
		// conCode.gridx = GridBagConstraints.RELATIVE;
		conCode.insets = new Insets(2,2,2,2);
		conCode.weighty = 1;
		
		conCode.gridx = 0;
		gblCode.setConstraints(instrLBL,conCode);
		
		conCode.gridx = GridBagConstraints.RELATIVE;
		gblCode.setConstraints(instructionTF,conCode);
		
		conCode.fill = GridBagConstraints.HORIZONTAL;
		gblCode.setConstraints(binaryInstruction,conCode);
	
		conCode.gridx = 0;
		conCode.gridy = 1;
		conCode.fill = GridBagConstraints.NONE;
		gblCode.setConstraints(operandLBL,conCode);
		
		conCode.gridx = GridBagConstraints.RELATIVE;
		gblCode.setConstraints(operandTF,conCode);
		
		conCode.fill = GridBagConstraints.HORIZONTAL;
		gblCode.setConstraints(binaryOperand,conCode);
		
		conCode.gridx = 0;
		conCode.gridy = 2;
		conCode.fill = GridBagConstraints.NONE;
		gblCode.setConstraints(commentHdr,conCode);
		
		conCode.gridx = 1;
		conCode.fill = GridBagConstraints.HORIZONTAL;
		gblCode.setConstraints(commentLbl,conCode);
		
		codePane.add(instrLBL);
		codePane.add(instructionTF);
		codePane.add(binaryInstruction);
		
		codePane.add(operandLBL);
		codePane.add(operandTF);
		codePane.add(binaryOperand);
		
		codePane.add(commentHdr);
		codePane.add(commentLbl);
		
		codePane.setBackground(new Color(128,192,128));

		// Create the button pane for the editor
		editBtn = new JButton("Edit");
		editBtn.addActionListener(this);

		replaceBtn = new JButton("Replace");
		replaceBtn.addActionListener(this);
		
		insertBtn = new JButton("Insert");
		insertBtn.addActionListener(this);
		
		deleteBtn = new JButton("Delete");
		deleteBtn.addActionListener(this);
		
		btnPane = new JPanel(new GridLayout(1,5,pad,pad));		
		btnPane.add(editBtn);
		btnPane.add(replaceBtn);
		btnPane.add(insertBtn);
		btnPane.add(deleteBtn);
		
		
		// Create the code listing pane
		codeList = new List(14);
		// Add a header row
		codeList.add(headerLine);
		// Add some sample code to test the program with
		codeList.add("1200 ildc 0 push 0 onto stack");
		codeList.add("3601 istr 1 pop top element of stack, store in 2nd local var");
		codeList.add("1500 ilod 0 push 1st local variable onto stack");

	    // Create the file IO pane, IO text fields and buttons,
	    // then add them to the interface
	    ioPane = new JPanel(new GridLayout(2,4,pad,pad));
		inputFileNameTF = new JTextField("",40);
		loadBrowseBtn = new JButton("Browse...");
		loadBrowseBtn.addActionListener(this);
		loadFileBtn = new JButton("Load");
		loadFileBtn.addActionListener(this);
		
		ioPane.add(new JLabel("Input filename:",SwingConstants.RIGHT));      
		ioPane.add(inputFileNameTF);
		ioPane.add(loadBrowseBtn);
		ioPane.add(loadFileBtn);
		
		outputFileNameTF = new JTextField("",40);
		saveBrowseBtn = new JButton("Browse...");
		saveBrowseBtn.addActionListener(this);
		saveFileBtn = new JButton("Save");
		saveFileBtn.addActionListener(this);
		ioPane.add(new JLabel("Output filename:",SwingConstants.RIGHT));
		ioPane.add(outputFileNameTF);   
		ioPane.add(saveBrowseBtn);
		ioPane.add(saveFileBtn);	    
		
		// Add the main components to the GUI
		gblGUI = new GridBagLayout();
		conGUI = new GridBagConstraints();
		conGUI.gridwidth = GridBagConstraints.REMAINDER;
		conGUI.weightx = 1.0;
			
		gui = new JPanel(gblGUI);	
		
		conGUI.fill = GridBagConstraints.HORIZONTAL;
		gblGUI.setConstraints(codePane,conGUI);
		gui.add(codePane);
		
		conGUI.fill = GridBagConstraints.NONE;
		gblGUI.setConstraints(btnPane,conGUI);
		gui.add(btnPane);
		
		conGUI.fill = GridBagConstraints.BOTH;
		gblGUI.setConstraints(codeList,conGUI);
		gui.add(codeList);
		
		conGUI.fill = GridBagConstraints.NONE;
		gblGUI.setConstraints(ioPane,conGUI);
		gui.add(ioPane);
		
		// Tell the JFrame that this is our GUI
		getContentPane().add(gui);
	}
	
	/**
	 * makeInstructionLine creates a line of code that can be inserted 
	 * into the code listing. It pieces this together by extracting
	 * the contents of the instruction text field, the operand text
	 * field and a manufactured comment.
	 * 
	 * @return	The line to insert into the code listing
	 */
	private String makeInstructionLine()
	{
		String instr = instructionTF.getText();
		String operand = operandTF.getText();
		String comment = getComment(instr,operand);
			
		commentLbl.setText(comment);
		
		if (instr.equals("")) return "";
		
		return (getHexInstruction(instr,operand) + sep + instr + sep + operand + sep + comment);		
	}
	
	
	/**
	 * 	Respond to user events
	 * 
	 * @param	e	The event that has just occurred
	 */
	public void actionPerformed(ActionEvent e) {
		
		int selected = -1;
		
		//	Check if user has pressed the Edit button
		if (e.getSource() == editBtn)
		{
			selected = codeList.getSelectedIndex();
			if (selected > 0) updateSelection();
		}
			
		//	Check if user has pressed the Delete button
		if (e.getSource() == deleteBtn)
			if (codeList.getSelectedIndex() != -1)
			{
				codeList.remove(codeList.getSelectedIndex());
				clearCodeText();
			}
			
		//	Check if user has pressed the Replace button
		if (e.getSource() == replaceBtn)
		{
			// Find out which, if any, item is selected
			int item = codeList.getSelectedIndex();
			if (item != -1)
			{			
				String line = makeInstructionLine();
				codeList.replaceItem(line,item);
			}	
		}
		
		//	Check if user has pressed the Add button
		if (e.getSource() == insertBtn)
		{
			// Find out which, if any, item is selected
			int item = codeList.getSelectedIndex();
			if (item != -1) // If we have a line
			{			
				String line = makeInstructionLine();
				codeList.add(line,item+1);
			}	
		}

		try
		{
			//	Check if user has pressed the load file browse button
			if (e.getSource() == loadBrowseBtn)
			{
				inputFileNameTF.setText(browseFile(this,true));
				loadFile(inputFileNameTF.getText());
			}
	
			//	Check if user has pressed the save file browse button
			if (e.getSource() == saveBrowseBtn)
			{
				outputFileNameTF.setText(browseFile(this,false));
				saveFile(outputFileNameTF.getText());
			}

			//	Check if user has pressed the save file button
			if (e.getSource() == loadFileBtn)
				loadFile(inputFileNameTF.getText());
			
			//	Check if user has pressed the save file button
			if (e.getSource() == saveFileBtn)
				saveFile(outputFileNameTF.getText());
		}
		catch (IOException ex)
		{
			System.err.println("Some trouble occured trying to do IO..." + ex.toString());
		}
		
		
	}

	/**
	 * Clear the contents of the code line edit boxes
	 */
	private void clearCodeText()
	{
		instructionTF.setText("");
		operandTF.setText("");
		commentLbl.setText(" ");
	}
	
	/**
	 * The method 'updateSelection' extracts information from the 
	 * current selected line in the code listing and places this
	 * information into the relevant edit boxes.
	 */
	private void updateSelection() {
		
		String command = "";
		String instr = "";
		String operand = "";
		String comment = "";
		
		// Double check that we have a selected item
		if (codeList.getSelectedIndex() == -1) return;
		
		// Now get the selected text as a String
		String	codeLine = codeList.getSelectedItem();
		
		// Break it up into its 4 pieces (using value of delimiter 'sep')
		StringTokenizer	st = new StringTokenizer(codeLine,sep);
		
		// The first token in the line is the hex instruction
		command = st.nextToken();
		// This is followed by the mnemonic for the instruction
		instr = st.nextToken();
		// Then we have the operand/parameter for the instruction
		operand = st.nextToken();

		// Finally we have a comment to tell us what on earth is going on...
		comment = st.nextToken();
		
		// Set the instruction and operand text fields to the 
		// relevant values
		instructionTF.setText(instr);
		operandTF.setText(operand);
		
		// Show the binary representation of the instruction and operand
		String hexInstr = command.substring(0,2);
		String hexOp = command.substring(2,4);
		
		binaryInstruction.setText(hexInstr + " [" + getBinaryForm(hexInstr) + "]");
		binaryOperand.setText(hexOp + " [" + getBinaryForm(hexOp) + "]");
		
		// Display the automatically generated comment
		commentLbl.setText(getComment(instr,operand));
	}
	


	
	
	// --- Assignment Code From Here Down --- //
	
	/**
	 * 	'browseFile' - If the parameter 'load' is true, this method 
	 * should prompt the user for a file name to load a program from 
	 * and then return the file name the user selected as a String. 
	 * If the parameter 'load' is false, the method should prompt the 
	 * user for a file name to save a file to, then return 
	 * the file name the user selected as a String. Hint: The
	 * method could use very similar code for both actions but
	 * just change how the initial FileDialog class is created
	 * depending on the value of 'load'.
	 * 	
	 * The method is called in actionPerformed when the user clicks
	 * on either of the 'Browse' buttons. The value of 'load' is
	 * determined by which of the two buttons was clicked.
	 * 	
	 * @param parent	A reference to the parent window
	 * @param load		If true, create a load file dialog, if false, create a save file dialog
	 * @return			The name of the file to load or save
	 */
	private String browseFile(Frame parent, boolean load)
	{
		// Implementation code required here
		
		return "";
			
	}
	
	/**

	'saveFile' should save the contents of the list control 'codeList'
	to the file provided in 'filename' in a format
	that would be suitable for use with 'loadFile'. For this
	reason the first line should contain the start address and
	nothing else. The following lines should list each seperate
	instruction with its associated comments. An example of how 
	all this information is sent to the standard console is already
	provided - your job is to convert this code to send it to a file.
	
	
	This method is called by actionPerformed whenever you
	click on the 'Save' button.

	@param filename		The name of the file to save the program to
	 
	*/	
	private void saveFile(String filename) throws IOException
	{
		System.out.println("I should be trying to save the program to the file: " + filename);
		System.out.println("For now I'm just sending it to the console...");
		
		// The first line should contain the starting address for the program
		// We are always going to use the value '40'.
		System.out.println("40");
		// This shows you how to access each line in the code list
		// Note that we miss out the first header line
		for (int l=1; l<codeList.getItemCount(); l++)
		{
			System.out.println(codeList.getItem(l));
		}
		
		// You should convert the above code to send output
		// to a file instead of the standard console output.
	}

	/**

	'loadFile' should load the program from the file provided in 
	'filename' into the list control referenced by 'codeList'.
	An example of how to add a line to this control is given below.
	The method is called by actionPerformed whenever the user 
	clicks on the 'Load' button. 
	
	You should therefore open the file referenced by 'filename'
	and proceed to read in its contents. For each line you read,
	you should insert the line into the codeList control using
	the 'add' method. For example:  
	
	codeList.add(line);
	
	The first line of the file will contain the memory address where
	the program should be loaded (default value 40). Just read this
	line first and discard it.

	@param filename		The name of the file to load the program from
	
	*/		
	private void loadFile(String filename) throws IOException
	{
		System.out.println("I should be trying to load the program from the file: " + filename);
		
		// You will need to empty the code list first
		codeList.removeAll();
		// Then put back the header line
		codeList.add(headerLine);
		
		// You can add a line to the code list like this...
		String line = "1200 lcd 0 push 0 onto stack";
		codeList.add(line);
		
		
		// Implementation code required here
	}
	

	/**
	 * 'padOut' is a useful utility method that pads out a supplied string
	 * such that it becomes 'size' characters long. The character used to 
	 * pad out 'str' is given by 'ch'. For example, if padOut was called as 
	 * follows: 
	 * 
	 * 	padOut("1011",8,'0')
	 * 
	 * it should return the string "00001011". If 'str' is longer than 'size'
	 * characters, then 'padOut' should return the first 'size' characters of
	 * 'str'. For example, if you called 'padOut' with 
	 * 
	 * padOut("101010110011",8,'0')
	 * 
	 * then it should return the string ""10101011".
	 * 
	 * @param str	The original string that needs padding out
	 * @param size	The size that you would like it to become
	 * @param ch	The character you would like to fill it out with
	 * @return		The padded out version of 'str'
	 */
	private String padOut(String str, int size, char ch)
	{
		// Implementation code required here
		
		return str;
	}

	/**
	 * The method 'getHexInstruction' should return the hexadecimal code that is
	 * represented by the supplied instruction and operand. For example if
	 * 'getHexInstruction' was called as follows:
	 * 
	 * 	getHexInstruction("ildc",4)
	 * 
	 * then it should return the string "1204". You should notice that the
	 * supplied operand value of '4' has been padded out with leading 0s. Your
	 * padOut method will prove very useful in achieving this effect.
	 * 
	 * @param instr		The mnemonic for an instruction, e.g. "ildc"
	 * @param operand	An associated operand (parameter) e.g. "4"  
	 * @return			The hex coding for the supplied instruction and operand e.g. "1204"
	 */
	private String getHexInstruction(String instr, String operand)
	{
		// Implementation code required here
		
		return "0000";
		
	}
	
	/**
	 * The method getComment takes an instruction code and an operand
	 * (for example 'ildc' and '5') and returns a suitably structured
	 * comment. In the example, you should make it return a comment such
	 * as: "Push the value '5' onto the stack".
	 * 
	 * @param instr		The instruction to comment
	 * @param operand	The optional parameter that may or may not be used
	 * @return			A suitable comment for instruction
	 */
	private String getComment(String instr, String operand)
	{
		String comment = "Not recognised";
		
		return comment;
	}


	/**
	 * 'getBinaryForm' should return the binary representation for the
	 * hexadecimal string given in 'hexCode'. For example, if hexCode
	 * contained '05', this method should return the string "00000101".
	 * 
	 * @param hexCode	The hexadecimal code that needs converting to a string
	 * @return			The binary representation of the above code
	 */
	private String getBinaryForm(String hexCode)
	{
		String binForm = "00000000";
		
		// For this method, you will need to:
		// - Find out what the integer value of the hex string is (the Integer class has
		//   a method that will do this for you)
		// - Use another Integer method to convert your integer value into a binary string
		// - Pad the binary string out with leading zero's using padOut....
		// - return the vbinary alue you have worked out for 'binForm'
		
		return binForm;
	}
	
}
