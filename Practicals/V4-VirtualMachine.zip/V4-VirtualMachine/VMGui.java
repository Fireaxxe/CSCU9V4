/* 
   This file is the main section of the program for the
   VM4V4 machine (simulator), and within this file is
   the GUI, and also the control code listening out
   for button presses and textfield events.
   
   ****  You are not required to do any     **** 
   **** programming in this file VMGui.java ****
   
   Please also note that you don't have to understand any of
   the GUI code in this file. It's not necessary for the assignment.
   (Though of course if you are curious, you can peek at it!)

   However, some lines of code have been commented out, in order
   that your programs will compile initially.  As you implement
   the various methods required, you will have to uncomment some lines
   of code (as detailed in the assignment handout). 
   That is all you need to do to alter this file, and if you
   accidentally mess it up, don't worry, you can always go and get a 
   fresh copy of this file, because all of *your* code should be in
   the VMTools.java file.
                                                               */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;                       // This GUI uses the Swing
import javax.swing.border.*;                // mentioned in later lectures. 
import java.awt.image.*;

import java.lang.reflect.*;


public class VMGui extends JFrame implements ActionListener {

   VM vm;
   VMTools vmp;
   
   JPanel main, titlePane, machinePane, ioPane, inputPane, outputPane, cpuPane; 
   JPanel memoryPane, methodPane, stackPane, heapPane;
   JScrollPane scrollMemory, scrollStack, scrollHeap;

   JMenuItem elevenItem, tenItem, twelveItem, fourteenItem, quitItem;

   int fontSize = 12;                     // Changing this value will change the 
                                          // default font size - feel free to do so
                                          // if you want a bigger/smaller font

   Dimension prefScroll                   // Changing this value will change the
          = new Dimension(180,320);       // default width/height of the scroll views
                                          // (which might be useful if you changed 
                                          // the default font size)
                                        

   BufferedImage black,grey,blue,greyArrow,pinkArrow,title;
   ImageIcon blackI,greyI,blueI,greyArrowI,pinkArrowI;
   
   final int numMem = 256;                // total number of cells in memory
   final int numStack = 64;               // number allocated to frame area with stack
   final int numMeth = 64;                // number allocated to method area
   
   final Color machineColour = new Color(230,230,230);               // Allocating colours for
   final Color memoryColour = new Color(200,200,255);               // various pieces of the
   final Color localVarsColour = new Color(200,255,200);     // interface. Change if you
   final Color opStackColour = new Color(150,150,255);    // must, but don't make any
   final Color ioGreyColour = new Color(230,230,230);// two colours the same!

   final Color defaultLabelColour = new Color(0,0,0);
   final Color pcColour = new Color(200,182,200);
           
   final int pad = 4;

   JCell[] guiCells = new JCell[numMem];
   JLabel titleLabel, pcLabel, spLabel, lvLabel, lvLabel2, instrLabel;
   JLabel addressLabel, inputLabel, outputLabel; 
   JTextField pcTextField, spTextField,inputFilename, outputFilename;
   JTextField lvTextField, lvTextField2, instrTextField, translator;
   JButton loadFile,saveFile, execute;
   JButton loadDlg,saveDlg;

	public VMGui()
	{

      vm = new VM();               // create and initialize the virtual machine (VM)      
      vmp = new VMTools(vm);       // set up the part to do the parsing and IO      

      main = new JPanel(new BorderLayout(pad,pad));
      main.setBackground(machineColour);

      createImageIcons();
      // createTitleGraphics();
      // titleLabel = new JLabel();
      // titleLabel.setBackground(machineColour);
      // titleLabel.setIcon(new ImageIcon(title));
      // main.add(titleLabel,BorderLayout.NORTH);
      
      setUpMenuBar();
    
      machinePane = new JPanel(new BorderLayout(pad,pad));
      machinePane.setBackground(machineColour);

      setUpCPU();
      machinePane.add(cpuPane, BorderLayout.NORTH);
 
      setUpMemoryGUI();
      updateMemoryDisplayFromVM();
      
      machinePane.add(memoryPane, BorderLayout.CENTER);
      main.add(machinePane,BorderLayout.CENTER);

      setUpIO();      

      setFontSizes();

      arrangeListeners();
      
      /*
      Method[] meths = null;
      
      meths = getClass().getDeclaredMethods();
      
      for (int m=0; m<meths.length; m++)
      {
      	System.out.println(meths[m]);
      }
		*/
       
    }  

    public void createImageIcons(){    
      // making a square shape   
      Polygon p = new Polygon();
      p.addPoint(0,0);
      p.addPoint(10,0);
      p.addPoint(10,10);
      p.addPoint(0,10);
      
      // setting up some little square plain coloured images
      black =  new BufferedImage(10,10,BufferedImage.TYPE_INT_RGB);
      Graphics2D g2d = black.createGraphics();
      g2d.setColor(memoryColour);
      g2d.fill(p);
      
      grey =  new BufferedImage(10,10,BufferedImage.TYPE_INT_RGB);
      g2d = grey.createGraphics();
      g2d.setColor(opStackColour);
      g2d.fill(p);
      
      blue = new BufferedImage(10,10,BufferedImage.TYPE_INT_RGB);
      g2d = blue.createGraphics();
      g2d.setColor(localVarsColour);
      g2d.fill(p);
      
      // drawing the little coloured pointers for the PC and op stack pointer  
      greyArrow = new BufferedImage(10,10,BufferedImage.TYPE_INT_RGB);
      g2d = greyArrow.createGraphics();
      g2d.setColor(memoryColour);
      g2d.fill(p);
      pinkArrow = new BufferedImage(10,10,BufferedImage.TYPE_INT_RGB);
      Graphics2D g2d2 = pinkArrow.createGraphics();
      g2d2.setColor(memoryColour);
      g2d2.fill(p);
      
      p = new Polygon();
      p.addPoint(0,0);
      p.addPoint(9,5);
      p.addPoint(0,9);
      
      g2d2.setColor(pcColour);
      g2d2.fill(p);      
      g2d2.setColor(Color.black);
      g2d2.draw(p);
      
      g2d.setColor(opStackColour);
      g2d.fill(p);
      g2d.setColor(Color.black);
      g2d.draw(p);

      blackI = new ImageIcon(black);
      greyI = new ImageIcon(grey);
      blueI = new ImageIcon(blue);
      greyArrowI = new ImageIcon(greyArrow);
      pinkArrowI = new ImageIcon(pinkArrow);
      
   } // end of createImageIcons
   
   public void createTitleGraphics() {
      // Creating the VM4V4 title
      title =  new BufferedImage(95,30,BufferedImage.TYPE_INT_RGB);
      Graphics2D g2d = title.createGraphics();
      g2d.setFont(new Font("Courier",Font.BOLD,24));
 
      int greyStep = 20;
      int g;
      for (int x=20; x>12; x--) {
        g = (20-x)*greyStep;
        g2d.setColor(new Color(g,g,g));
        g2d.drawString("V4-VM",x,8+x);
      }
      g2d.setColor(Color.green);
      g2d.drawString("V4-VM",12,20);
  } // end of createTitleGraphics
  
  public void setUpMenuBar() {
     JMenuBar theMenuBar = new JMenuBar();
     setJMenuBar(theMenuBar);

     JMenu theFileMenu = new JMenu("File");      
     theMenuBar.add(theFileMenu);               
     quitItem = new JMenuItem("Quit");
     theFileMenu.add(quitItem);
     
     JMenu theFontMenu = new JMenu("Font");
     theMenuBar.add(theFontMenu);
     tenItem = new JMenuItem("Size 10");
     theFontMenu.add(tenItem);
     elevenItem = new JMenuItem("Size 11");
     theFontMenu.add(elevenItem);
     twelveItem = new JMenuItem("Size 12");
     theFontMenu.add(twelveItem);
     fourteenItem = new JMenuItem("Size 14");
     theFontMenu.add(fourteenItem);
  
  
  } // end of setUpMenuBar
  
  public void setUpCPU(){
      
 
      
      // setting up the panel at the top to contain the registers
      cpuPane = new JPanel(new GridLayout(1,2,pad,pad));
      cpuPane.setBackground(machineColour);
      
      JPanel registersTopPane = new JPanel(new GridLayout(4,2,pad,pad));
      registersTopPane.setBackground(machineColour);

      lvLabel2 = new JLabel("Local Variables:",SwingConstants.RIGHT);
      lvLabel2.setForeground(defaultLabelColour);
      registersTopPane.add(lvLabel2);
 
      lvTextField2 = new JTextField(vmp.convertInteger2HexString(vm.numLocalVars),3);
      lvTextField2.setBackground(localVarsColour);
      lvTextField2.setForeground(defaultLabelColour);
      lvTextField2.setEditable(false);
      registersTopPane.add(lvTextField2);
      
 
      lvLabel = new JLabel("Local Variables Pointer:",SwingConstants.RIGHT);
      lvLabel.setForeground(defaultLabelColour);
      registersTopPane.add(lvLabel);
      lvTextField = new JTextField(vmp.convertInteger2HexString(vm.localVarsPointer),3);
      
      lvTextField.setBackground(localVarsColour);
      lvTextField.setForeground(defaultLabelColour);
      lvTextField.setEditable(false);
      registersTopPane.add(lvTextField);
      
      // registersTopPane.add(new JLabel(blackI));      
      // registersTopPane.add(new JLabel(blackI));
            
      spLabel = new JLabel("Stack Pointer:",SwingConstants.RIGHT);
      spLabel.setForeground(defaultLabelColour);
      registersTopPane.add(spLabel);

      spTextField = new JTextField(vmp.convertInteger2HexString(vm.opStackPointer),3);
      spTextField.setBackground(opStackColour);
      spTextField.setForeground(defaultLabelColour);
      registersTopPane.add(spTextField);

      registersTopPane.add(new JLabel(" "));
      registersTopPane.add(new JLabel(" "));

      cpuPane.add(registersTopPane,BorderLayout.NORTH); 

      JPanel registersBottomPane = new JPanel(new GridLayout(4,2,pad,pad));
      registersBottomPane.setBackground(machineColour);

      
      // registersBottomPane.add(new JLabel(blackI));
      // registersBottomPane.add(new JLabel(blackI));    
      // registersBottomPane.add(new JLabel(blackI));
      
      pcLabel = new JLabel("Program Counter:",SwingConstants.RIGHT);
      pcLabel.setForeground(defaultLabelColour);      
      registersBottomPane.add(pcLabel);

      String s = vmp.convertInteger2HexString(vm.programCounter);
      pcTextField = new JTextField(s,3);
      pcTextField.setBackground(pcColour);
      registersBottomPane.add(pcTextField);

      instrLabel = new JLabel("Instruction Register:",SwingConstants.RIGHT);
      instrLabel.setForeground(defaultLabelColour);
      registersBottomPane.add(instrLabel);
      
      s = vmp.convertInteger2HexString(vm.memory[vm.programCounter].getContents())
          + vmp.convertInteger2HexString(vm.memory[vm.programCounter+1].getContents());
      instrTextField = new JTextField(s,5);
      instrTextField.setForeground(defaultLabelColour);
      instrTextField.setBackground(pcColour);
      instrTextField.setEditable(false);
      registersBottomPane.add(instrTextField);

      registersBottomPane.add(new JLabel("Translation:",SwingConstants.RIGHT));
      
      translator = new JTextField("",12);
      translator.setForeground(Color.white);
      translator.setBackground(pcColour);
      translator.setEditable(false);
      registersBottomPane.add(translator);

      registersBottomPane.add(new JLabel(" "));
      execute = new JButton("Execute Instruction");
      registersBottomPane.add(execute);
                 
      cpuPane.add(registersBottomPane,BorderLayout.SOUTH); 
      
      /*
      System.out.println("Int:4 Hex:" + vmp.intToHexString(4)); 
      vmp.hexStringToInt("4");
      vmp.hexStringToInt("04");
      
      System.out.println("Int:-3 Hex:" + vmp.intToHexString(-3));  
      vmp.hexStringToInt("fd");

      System.out.println("Int:-128 Hex:" + vmp.intToHexString(-128));  
      vmp.hexStringToInt("80");

      System.out.println("Int:-127 Hex:" + vmp.intToHexString(-127));  
      vmp.hexStringToInt("81");

      System.out.println("Int:-1 Hex:" + vmp.intToHexString(-1));  
      vmp.hexStringToInt("ff");

      System.out.println("Int:127 Hex:" + vmp.intToHexString(127));  
      vmp.hexStringToInt("7f");
      
      vmp.hexStringToInt("fd");
      vmp.hexStringToInt("f0");
      vmp.hexStringToInt("0F");
      vmp.hexStringToInt("CC");
      vmp.hexStringToInt("EE");
      vmp.hexStringToInt("98");

      vmp.hexStringToInt("1a");
      vmp.hexStringToInt("ff");
      
      System.out.println("Int:127 Binary:" + vmp.intToByteString(127));
      System.out.println("Int:0 Binary:" + vmp.intToByteString(0));
      System.out.println("Int:-1 Binary:" + vmp.intToByteString(-1));
      System.out.println("Int:-2 Binary:" + vmp.intToByteString(-2));
      System.out.println("Int:-3 Binary:" + vmp.intToByteString(-3));
      
      System.out.println("ages 8 . '" + vmp.padOut("ages",8,'.') + "'");
      System.out.println("9.99 6 _ '" + vmp.padOut("9.99",6,' ') + "'");
      System.out.println("ssh! 20 s '" + vmp.padOut("ssh!",20,'s') + "'");
      System.out.println("sausages 8 . '" + vmp.padOut("sausages",8,'.') + "'");
      System.out.println("more sausages 8 . '" + vmp.padOut("more sausages",8,'.') + "'");
      */
          
  } // end of setUpCPU
  
  public void setUpMemoryGUI(){
     
      /* memoryPane is a panel to display the memory
         There are three sections: 
           one to be used for the frame, including local vars and a stack (stackPane),
           one to be used for programs (methodPane),
           one which would be used for the heap and garbage collection (heapPane), 
         (although heapPane won't be used much in this simulation)

         In this simulation, the frame area will take up the first portion of memory,
         then comes the method area, and finally, the heap area.
      */      

      memoryPane = new JPanel(new GridLayout(1,3,pad,pad));
      memoryPane.setBackground(machineColour);

		/*
      addressLabel = new JLabel("Address (in hex):");
      addressLabel.setForeground(defaultLabelColour);
      addressLabel.setHorizontalAlignment(SwingConstants.LEFT);
      memoryPane.add(new JLabel("Memory"));
      memoryPane.add(new JLabel("?"));
      memoryPane.add(new JLabel("?"));
      */


      // stackPane holds the memory cells in the range [0..numStack)
      stackPane = new JPanel(new GridLayout(numStack+1,1));
      stackPane.setBackground(machineColour);
      
      // adding GUI displays for the cells in 
      // the stack area of memory      
      stackPane.add(new JLabel("Thread Memory",SwingConstants.CENTER));     
      for (int row=0; row<numStack; row++) {
        guiCells[row] = new JCell(row);
        stackPane.add(guiCells[row]);
      }
      
      scrollStack = new JScrollPane();
      scrollStack.setPreferredSize(prefScroll);       
      scrollStack.setViewportView(stackPane);      
      scrollStack.getVerticalScrollBar().setBackground(machineColour);
      memoryPane.add(scrollStack);


      methodPane = new JPanel(new GridLayout(numMeth+1,1));
      methodPane.setBackground(machineColour);
      
      // adding GUI displays for the cells in 
      // the method (program) area of memory      
      methodPane.add(new JLabel("Method Memory",SwingConstants.CENTER));     
      for (int row=numStack; row<numStack+numMeth; row++) {
        guiCells[row] = new JCell(row);
        methodPane.add(guiCells[row]);
      }
      
      scrollMemory = new JScrollPane();
      scrollMemory.setPreferredSize(prefScroll);       
      scrollMemory.setViewportView(methodPane);
      scrollMemory.getVerticalScrollBar().setBackground(machineColour);
      memoryPane.add(scrollMemory);

      
      heapPane = new JPanel(new GridLayout(numMem-numStack-numMeth+1,1));
      heapPane.setBackground(machineColour);

      // adding GUI displays for the cells in 
      // the heap/garbage collection area of memory 
      heapPane.add(new JLabel("Heap Memory",SwingConstants.CENTER));     
      for (int i=numMeth+numStack; i<numMem; i++) {
        guiCells[i] = new JCell(i);
        heapPane.add(guiCells[i]);
      }
      
      scrollHeap = new JScrollPane();
      scrollHeap.setPreferredSize(prefScroll);       
      scrollHeap.setViewportView(heapPane);      
      scrollHeap.getVerticalScrollBar().setBackground(machineColour);
      memoryPane.add(scrollHeap);
  } // end of setUpMemoryGUI

  public void updateMemoryDisplayFromVM() {
      for (int i=0; i < numMem; i++)
        guiCells[i].updateCell(vm.memory[i].getContents());
  }

  public void setUpIO() {
  /* Sets up the GUI for the area at the bottom of the screen,
     containing components for input and output from/to files. */
      
      ioPane = new JPanel(new GridLayout(2,4,pad,pad));
      ioPane.setBackground(ioGreyColour);
      
      inputLabel = new JLabel("Input filename:",SwingConstants.RIGHT);
      inputFilename = new JTextField("",20);
      loadDlg = new JButton("Browse...");
      loadFile = new JButton("Load Memory");

      ioPane.add(inputLabel);      
      ioPane.add(inputFilename);
      ioPane.add(loadDlg);
      ioPane.add(loadFile);

      outputLabel = new JLabel("Output filename:",SwingConstants.RIGHT);
      outputFilename = new JTextField("",20);
      saveDlg = new JButton("Browse...");
      saveFile = new JButton("Save Memory");
      
      ioPane.add(outputLabel);
      ioPane.add(outputFilename);   
      ioPane.add(saveDlg);
      ioPane.add(saveFile);
      
      main.add(ioPane,BorderLayout.SOUTH);
      getContentPane().add(main);

	} // end of setUpIO

   public void setFontSizes() {
      Font fixedFont = new Font("Courier",Font.BOLD,fontSize);
      Font varFont = new Font("Helvetica",Font.BOLD,fontSize);

      lvLabel.setFont(varFont);
      lvTextField.setFont(fixedFont);
      lvLabel2.setFont(varFont);
      lvTextField2.setFont(fixedFont);


      // addressLabel.setFont(varFont);
      
      spLabel.setFont(varFont);
      spTextField.setFont(fixedFont);
 
      pcLabel.setFont(varFont);
      pcTextField.setFont(fixedFont);
 
      instrLabel.setFont(varFont);
      instrTextField.setFont(fixedFont);
 
      execute.setFont(varFont);

      for (int i=0; i < numMem; i++) {
        guiCells[i].binary.setFont(fixedFont);
        guiCells[i].integer.setFont(fixedFont);
        guiCells[i].hex.setFont(fixedFont);
        guiCells[i].memAddress.setFont(fixedFont);
      }
        
      inputLabel.setFont(varFont);
      inputFilename.setFont(fixedFont);
 
      saveFile.setFont(varFont);
      outputLabel.setFont(varFont);
      outputFilename.setFont(fixedFont);
   } // end of setFontSizes

   public void arrangeListeners() {
   
     for (int i=0; i <numMem; i++)  
        guiCells[i].hex.addActionListener(this);

     pcTextField.addActionListener(this);
     spTextField.addActionListener(this);
     
     loadFile.addActionListener(this);
     inputFilename.addActionListener(this);
     
     saveFile.addActionListener(this);
     outputFilename.addActionListener(this);
     
     quitItem.addActionListener(this);

     execute.addActionListener(this);

     elevenItem.addActionListener(this);
     tenItem.addActionListener(this);
     twelveItem.addActionListener(this);
     fourteenItem.addActionListener(this);
     
     loadDlg.addActionListener(this);
     saveDlg.addActionListener(this);
     

	  this.addWindowListener	(new WindowAdapter(){
	    	public void windowClosing(WindowEvent e){
				dispose();
				System.exit(0);
			}
		});

   }


   public void actionPerformed(ActionEvent e) {
   
     Object obj = e.getSource();
     String	str;
     
     // quit menu option selected
     if (obj == quitItem) {
         dispose();
         System.exit(0);  
     }

     // changing the font size
     else if (obj == elevenItem) {
       fontSize = 11;
       setFontSizes();
     }
     else if (obj == tenItem) {
       fontSize = 10;
       setFontSizes();
     }
     else if (obj == twelveItem) {
       fontSize = 12;
       setFontSizes();
     }
     else if (obj == fourteenItem) {
       fontSize = 14;
       setFontSizes();
     }
     
      
     // loading an input file
  // When you have implemented loadFromFile, uncomment the following ten lines:
     if ((obj == loadFile) || (obj == inputFilename)) {
       String name = inputFilename.getText();
       System.out.println("Opening input file: "+name);
       try {
         vmp.loadState(name);
       }
       catch (Exception ex) {
         System.out.println(ex);
       }
     }
     
     // saving into an output file
  // When you have implemented saveToFile, uncomment the following ten lines:     
     if ((obj == saveFile) || (obj == outputFilename)) {
        String name = outputFilename.getText();
        System.out.println("Writing to output file: "+name);
        try {
          vmp.saveState(name);
        }
        catch (Exception ex) {
          System.out.println("(Couldn't write to file)");
        }
     }  
       
     // changing program counter, if in range
  // When you have implemented hexStringToInt, uncomment the following five lines:     
     else if (obj == pcTextField) {
        int pc = vmp.hexStringToInt(pcTextField.getText());
        if ((numStack <= pc) && (pc < numMem))   // program counter within range
           vm.programCounter = pc;
     }

     // changing stack pointer, if in range
  // When you have implemented hexStringToInt, uncomment the following five lines:     
     else if (obj == spTextField) {
       int sp = vmp.hexStringToInt(spTextField.getText());
       if ((vm.numLocalVars <= sp) && (sp < numStack))  // stack pointer within range
         vm.opStackPointer = sp;
     }

     // time to execute the instruction in the IR
  // When you have implemented executeInstruction, uncomment the following four lines:     
     else if (obj == execute) {
        String instr = instrTextField.getText();
        vmp.executeInstruction(instr);
     }
     
     else if (obj == loadDlg) {
	     str = vmp.browseFile(this,true);
	     if (str != null)
	     {
	     	  inputFilename.setText(str);
       	  vmp.loadState(str);
	     }    
	  }
     
     else if (obj == saveDlg) {
		  str = vmp.browseFile(this,false);
		  if (str != null)
		  {
     	  		outputFilename.setText(str);
			   vmp.saveState(str);
		  }
	  }
     
     // updating memory cell
  // When you have implemented hexStringToInt, uncomment the following eleven lines:     
     else if (obj instanceof JTextField) {
       JTextField jt = (JTextField)obj;
       Object obj2 = jt.getParent();
       if (obj2 instanceof JCell) {
         JCell jc = (JCell) obj2;
         int i = vmp.hexStringToInt(jt.getText());
         if ((-128 <= i) && (i <= 127)) {          // integer within permitted 2C range
           vm.memory[jc.cellId].setContents(i);
         }    
       }
     } 
     updateGUI();
     repaint();
   }

   public void updateGUI() {
   
     updateMemoryDisplayFromVM();

     // updating the stack pointer and program counter registers
     
  // When you have implemented intToHexString, uncomment the following line:
     spTextField.setText(vmp.convertInteger2HexString(vm.opStackPointer));

  // When you have implemented intToHexString, uncomment the following line:
     pcTextField.setText(vmp.convertInteger2HexString(vm.programCounter));

     // updating the display of the instruction register from
     // memory, depending on which instruction is being pointed at
     
  // When you have implemented intToHexString, uncomment the following three lines: 
     String s = vmp.convertInteger2HexString(vm.memory[vm.programCounter].getContents())
              + vmp.convertInteger2HexString(vm.memory[vm.programCounter+1].getContents());
     instrTextField.setText(s);
     
     
  // Once you have implemented the translate method, uncomment the following line:
  translator.setText(vmp.padOut(vmp.translate(s),2,'0'));

   }
	
	public static void main(String args[])
	{
		System.out.println("Starting the V4 Virtual Machine");
		VMGui vmg = new VMGui();
		vmg.setSize(640,480);
		vmg.setTitle("V4 Virtual Machine");
		// BufferedImage bf = new BufferedImage(19,19,BufferedImage.TYPE_INT_RGB);
		// vmg.setIconImage(bf);
		vmg.show();
				
	}





/* A JCell is intended to display a single memory cell. 
   The display consists of:
      8 bits giving the cell's contents in binary
      a textfield containing the cell's contents in hex
      a further label giving the cell's contents in decimal
   The textfield is editable, so that it is possible for the user
   of the simulator to change the value in memory by entering a
   new number in the textfield and pressing the return key.       */
	
class JCell extends JPanel {

  int cellId;
  Color binaryCol = defaultLabelColour;
  Color hexCol = defaultLabelColour;
  Color integerCol = defaultLabelColour;
  JLabel binary, integer, memAddress;
  JTextField hex;
  ImageIcon stackIm;
	
  public JCell (int i) {
    super(new FlowLayout());
    
    cellId = i;
    
    // now to label which cell this is
    
 // When you have implemented intToHexString, comment out the following line:  
 //   String s = "";  // empty should be the original when started
 // ... and uncomment the following line: 
    String s = vmp.convertInteger2HexString(cellId);
    
    if (cellId < vm.numLocalVars)
      stackIm = blueI;
    else if (cellId == vm.opStackPointer) 
      stackIm = greyArrowI;
    else if ((cellId >= vm.numLocalVars) && (cellId < vm.opStackPointer))
      stackIm = greyI;
    else if (cellId == vm.programCounter)
      stackIm = pinkArrowI;
    else
      stackIm = blackI;
    memAddress = new JLabel(s+":",stackIm,SwingConstants.RIGHT);
    
    memAddress.setHorizontalTextPosition(SwingConstants.RIGHT);
    memAddress.setForeground(defaultLabelColour);
    add(memAddress);
    
    binary = memLabel("        ",binaryCol);
    add(binary);
    
    hex = new JTextField("  ",3);
    hex.setFont(new Font("Courier",Font.BOLD,fontSize));
    hex.setHorizontalAlignment(SwingConstants.CENTER);
    add(hex);
    
    integer = memLabel("   0", integerCol);
    add(integer);
     
    if (i < vm.numLocalVars) 
      setBackground(localVarsColour);
    else if ((i>=numMeth) && (i < vm.opStackPointer))
      setBackground(opStackColour);
    else
      setBackground(memoryColour);
  	
	 setBorder(new LineBorder(Color.black,0));
  }
  
  private JLabel memLabel(String txt, Color col) {
    JLabel m = new JLabel(txt,SwingConstants.RIGHT);
    m.setForeground(col);
    m.setOpaque(true);
     m.setBackground(memoryColour);
    m.setBorder(new LineBorder(integerCol,0));
    return m;
  }
  
  public void updateCell(int newContents) {
    // Updates a memory cell with its new contents
    
    
    // Uncomment the following line once intToByteString is implemented
    binary.setText(vmp.intToByteString(newContents)); 
    
    
    // Uncomment the following line once intToHexString is implemented
    hex.setText(vmp.convertInteger2HexString(newContents));
    
    // The following line of code should be used until padOut is implemented: 
    // integer.setText(Integer.toString(newContents));     
    // ...  then it can be commented out and this line uncommented:
    integer.setText(vmp.padOut(Integer.toString(newContents),4,' '));
    
    // sets the correct background colour for the display of the cell
    if (cellId < vm.numLocalVars) 
      setBackground(localVarsColour);
    else if ((cellId >= vm.numLocalVars) && (cellId < vm.opStackPointer))
      setBackground(opStackColour);
    else
      setBackground(memoryColour);

    // sets the correct image (pointer or background colour)
    if (cellId < vm.numLocalVars)
      stackIm = blueI;
    else if (cellId == vm.opStackPointer) 
      stackIm = greyArrowI;
    else if ((cellId >= vm.numLocalVars) && (cellId < vm.opStackPointer))
      stackIm = greyI;
    else if (cellId == vm.programCounter)
      stackIm = pinkArrowI;
    else
      stackIm = blackI;
    memAddress.setIcon(stackIm);
  }
  
  public void setStackPointer() {
    // sets the display of this cell to indicate that the stack
    // pointer points to it
    stackIm = greyArrowI;
  }

  public void setPC() {
    // set the display of this cell to indicate that the program
    // counter points to it
    stackIm = pinkArrowI;
  }

  public void setBlack() {
    stackIm = blackI;
  }

  public void setOpStack() {
    stackIm = greyI;
  }
  

} // class JCell 	
	
}

// optional translation of machine code into opcode
// check out screen sizes on pooters downstairs
